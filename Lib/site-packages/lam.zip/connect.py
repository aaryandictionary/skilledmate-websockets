import json
from datetime import datetime
import boto3
import botocore
from aws_requests_auth.aws_auth import AWSRequestsAuth
import requests
from decimal import Decimal
import os
import sys
import logging
import pymysql

rds_host  = "skilledmate.cfbz13lsgo8m.ap-south-1.rds.amazonaws.com"
name = "SkilledMate"
password = "SkilledMate1998"
db_name = "skilledmate"

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()


def applambda(event,context):
    connectionId=event["requestContext"]["connectionId"]
    userId=event["queryStringParameters"]["userId"]

    sql="UPDATE users SET users.is_connected ='"+str(1)+"',users.connection_id='"+connectionId+"',users.seen_status='Online' WHERE users.id="+str(userId)

    myCursor=conn.cursor()
    myCursor.execute(sql)

    conn.commit()

    return {
        'isBase64Encoded':False,
        'statusCode': 200,
        'headers':{'status':'success'},
        'body': "success"
    }